package cs3500.freecell.view;

import cs3500.freecell.model.FreecellModel;
import cs3500.freecell.model.hw02.Pile;
import java.util.List;

/** Class for FreecellTextView which displays the Freecell game. */
public class FreecellTextView implements FreecellView {
  private final FreecellModel<?> model;
  protected List<Pile> openPile;
  protected List<Pile> cascadePile;
  protected List<Pile> foundationPile;
  private int totalPiles;

  /**
   * Constructs a FreecellTextView.
   *
   * @param model represents the game model
   */
  public FreecellTextView(FreecellModel<?> model) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null.");
    }

    this.model = model;
  }

  @Override
  public String toString() {
    if (this.model.getNumCascadePiles() == -1) {
      return "";
    }
    String textView = "";
    for (int i = 1; i < 5; i++) {
      textView += "F" + Integer.toString(i) + ":";
      for (int x = 0; x < this.model.getNumCardsInFoundationPile(i - 1); x++) {
        String card = model.getFoundationCardAt(i - 1, x).toString();
        textView += " " + card;
      }
      textView += "\n";
    }
    for (int j = 0; j < this.model.getNumOpenPiles(); j++) {
      textView += "O" + Integer.toString(j + 1) + ":";
      for (int y = 0; y < this.model.getNumCardsInOpenPile(j); y++) {
        String card = model.getOpenCardAt(y).toString();
        textView += " " + card;
      }
      textView += "\n";
    }
    for (int k = 0; k < this.model.getNumCascadePiles(); k++) {
      textView += "C" + Integer.toString(k + 1) + ":";
      for (int z = 0; z < this.model.getNumCardsInCascadePile(k); z++) {
        String card = model.getCascadeCardAt(k, z).toString();
        textView += " " + card;
      }
      if (k < this.model.getNumCascadePiles() - 1) {
        textView += "\n";
      }
    }
    return textView;
  }
}
