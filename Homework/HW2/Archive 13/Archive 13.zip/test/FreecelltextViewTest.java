/**
 * The class for the FreecelltextView tests.
 */
public class FreecelltextViewTest {


}
