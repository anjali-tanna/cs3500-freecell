package cs3500.freecell.model.hw02;

/**
 * This has not been implemented yet.
 */
public interface ICard {
  // put methods here (??)
}
